package Screens;

import java.io.IOException;

import AppScreens.Dashb;
import Widgets.ErrorWidget;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginScreen extends Application{

    Stage window;
    BackgroundImage backgroundImage; 

    
    public static void main(String [] args)throws IOException{
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        window = primaryStage;
        window.setTitle("Login Screen");

        // Label AppBarLabel = new Label("Hostel Management System");
        // AppBarLabel.setStyle("-fx-font-size: 60px;");
        // AppBarLabel.setPadding(new Insets(50, 0, 0, 30));
        // AppBarLabel.setAlignment(Pos.CENTER);
        
        
        // HBox appBarlayout = new HBox(10);
        // appBarlayout.getChildren().add(AppBarLabel);

        // BorderPane borderPane = new BorderPane();
        // borderPane.setTop(appBarlayout);

        GridPane dGridPane = new GridPane();
        dGridPane.setPadding(new Insets(300,0,50,60));
        dGridPane.setVgap(20);
        dGridPane.setHgap(20);

        dGridPane.setAlignment(Pos.CENTER);
//UserName
        Label namelabel1 = new Label("Email ID");
        namelabel1.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(namelabel1, 0, 1);

        TextField nameInput = new TextField("example@gmail.com");
        GridPane.setConstraints(nameInput, 1, 1);
        nameInput.setStyle("-fx-font-size: 25px;");

//Password

        Label Passwordlabel = new Label("Password");
        GridPane.setConstraints(Passwordlabel, 0, 2);
        Passwordlabel.setStyle("-fx-font-size: 25px;");

        PasswordField passInput = new PasswordField();
        passInput.setPromptText("*******");
        GridPane.setConstraints(passInput, 1, 2);
        passInput.setStyle("-fx-font-size: 25px;");

        Button logInButton = new Button("LogIn");
        GridPane.setConstraints(logInButton, 1, 3);
        logInButton.setStyle("-fx-font-size: 25px;");

        Label newlabel = new Label("Create new account");
        GridPane.setConstraints(newlabel, 0, 4);
        newlabel.setStyle("-fx-font-size: 25px;");

        Button signUpInButton = new Button("SignUp");
        GridPane.setConstraints(signUpInButton, 1, 4);
        signUpInButton.setStyle("-fx-font-size: 25px;");
        dGridPane.setAlignment(Pos.CENTER_LEFT);
        
        dGridPane.getChildren().addAll(namelabel1,nameInput,Passwordlabel,passInput,logInButton,newlabel,signUpInButton);

        BorderPane borderPane2 = new BorderPane();
        borderPane2.setLeft(dGridPane);

        VBox container = new VBox(100);
        container.getChildren().addAll(dGridPane);

        Scene scene = new Scene(container,1300,900);
        
        signUpInButton.setOnAction(e->{
            SignUpScreen.display(window,scene);
        });

        logInButton.setOnAction(e->{
            String emailId = nameInput.getText();
            String password = passInput.getText();
                
                if(emailId.length() == 0 || password.length() == 0){

                    ErrorWidget.display("Error Occured", "Field missing please enter.");
                }else if(!(emailId.contains("@"))){

                     ErrorWidget.display("Error Occured", "Invalid email Id");
                }else if(password.length() < 6){

                     ErrorWidget.display("Error Occured", "Password is too short. it must be grater than 6 digit ");
                }else{
                    
                    Dashb.display(window, scene);
                    System.out.println(emailId);
                    System.out.println(password);
                }
                
        });
        logInButton.getStyleClass().add("custom-button");
        signUpInButton.getStyleClass().add("custom-button");

        Image image = new Image("Image/hostel_management_software.jpg");
        backgroundImage = new BackgroundImage(
            image, 
            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, 
            BackgroundPosition.CENTER, 
           new BackgroundSize(1000, 1300, true, true, true, false)
        );
        scene.getStylesheets().add(getClass().getResource("/ThemeProvider.css").toExternalForm());


        container.setBackground(new Background(backgroundImage));
       
        //scene.getStylesheets().add("ThemeProvider.css");
        window.setScene(scene);
        window.show();
    }
}
