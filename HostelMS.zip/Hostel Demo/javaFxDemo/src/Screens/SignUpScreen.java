package Screens;

import Widgets.ErrorWidget;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SignUpScreen {

    static BackgroundImage backgroundImage;

    public static void display(Stage window,Scene scene2){
      
        
        window.setTitle("Sigup Screen");

        // Label AppBarLabel = new Label("Hostel Management System");
        // AppBarLabel.setStyle("-fx-font-size: 60px;");
        // AppBarLabel.setPadding(new Insets(50,0,0,30));
        // AppBarLabel.setAlignment(Pos.CENTER);
        
    
        VBox container = new VBox(100);
        

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(300,0,50,60));
        grid.setVgap(20);
        grid.setHgap(20);
        grid.setAlignment(Pos.CENTER_LEFT);

//For emailId
        Label userLabel = new Label("Email ID");
        GridPane.setConstraints(userLabel, 0, 1);
        userLabel.setStyle("-fx-font-size: 25px;");

        TextField userTextField = new TextField("example@gmail.com");
        GridPane.setConstraints(userTextField, 1, 1);
        userTextField.setStyle("-fx-font-size: 25px;");

//for password

        Label passLabel = new Label("Password");
        GridPane.setConstraints(passLabel, 0, 2);
        passLabel.setStyle("-fx-font-size: 25px;");

        PasswordField passTextField = new PasswordField();
        passTextField.setPromptText("******");
        GridPane.setConstraints(passTextField, 1, 2);
        passTextField.setStyle("-fx-font-size: 25px;");

//for confirm password

        Label confirmPassLabel = new Label("Confirm Password");
        GridPane.setConstraints(confirmPassLabel, 0, 3);
        confirmPassLabel.setStyle("-fx-font-size: 25px;");

        PasswordField confpaTextField = new PasswordField();
        GridPane.setConstraints(confpaTextField, 1, 3);
        confpaTextField.setStyle("-fx-font-size: 25px;");

//SignUp Button

        Button signUpButton = new Button("SignUp");
        GridPane.setConstraints(signUpButton, 1,4);
        signUpButton.setStyle("-fx-font-size: 25px;");

        Button backBtn = new Button("Back");
        GridPane.setConstraints(backBtn, 1, 5);
        backBtn.setStyle("-fx-font-size: 25px;");
        

        grid.getChildren().addAll(userLabel,userTextField,passLabel,passTextField,confirmPassLabel,confpaTextField,signUpButton,backBtn);
        container.getChildren().addAll(grid);

        Scene scene = new Scene(container, 1300, 900);

        //backButton
        backBtn.setOnAction(e->{
           window.setTitle("LogIn Page");
           window.setScene(scene2);
        });
        signUpButton.getStyleClass().add("custom-button");

        signUpButton.setOnAction(e->{
            String emailId = userTextField.getText();
            String password = passTextField.getText();
            String confirmPassword = confpaTextField.getText();

            if(emailId.length() == 0 || password.length() == 0 || confirmPassword.length() == 0){

                    ErrorWidget.display("Error Occured", "Field missing please enter.");
            }else if(!(emailId.contains("@"))){

                 ErrorWidget.display("Error Occured", "Invalid email Id");
            }else if(!password.equals(confirmPassword)){

                ErrorWidget.display("Error Occured", "Please confirm password");
            }else if(password.length() < 6){

                 ErrorWidget.display("Error Occured", "Password is too short. it must be grater than 6 digit ");
            }else{
                System.out.println(emailId);
                System.out.println(password);
                System.out.println(confirmPassword);
            }
        });
        Image image = new Image("Image/hostel_management_software.jpg");
        backgroundImage = new BackgroundImage(
            image, 
            BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, 
            BackgroundPosition.CENTER, 
           new BackgroundSize(1000, 1000, true, true, true, false)
        );
        backBtn.getStyleClass().add("custom-button1");

        scene.getStylesheets().add(SignUpScreen.class.getResource("/ThemeProvider.css").toExternalForm());

        container.setBackground(new Background(backgroundImage));

        window.setScene(scene);
        window.show();
    }
}
