package AppScreens;
import java.util.ArrayList;
import java.util.List;

import Models.Student;
import StateManagement.StudentList;
import javafx.geometry.Insets;

import javafx.scene.Scene;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ViewStudentDetailsScreen {

    static Stage window;
    static Scene primaryScene;

    static TableView<Student> tableView;
    static List<TableColumn<Student, ?>> columns;

    public static VBox display(){

        // primaryScene = scene;
        // window = primaryStage;

        //window.setTitle("Hostel Management System");

        // Label label = new Label("Student Details ");
        // label.setPadding(new Insets(10, 0, 0, 15));
        // label.setStyle("-fx-font-size: 60px;");
        // BorderPane borderPane = new BorderPane();
        // borderPane.setTop(label);

    //RoomNumber
        TableColumn<Student,Integer> roomColumn = new TableColumn<>("Room No.");
        roomColumn.setMinWidth(30);
        roomColumn.setCellValueFactory(new PropertyValueFactory<Student,Integer>("roomNumber"));

    //Student Name
        TableColumn<Student,String> nameColumn = new TableColumn<>("Name");
        nameColumn.setMinWidth(200);
        nameColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("studentName"));
    
    //Email
        TableColumn<Student,String> emailColumn = new TableColumn<>("Email");
        emailColumn.setMinWidth(200);
        emailColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("email"));
    
    //contactNumber
        TableColumn<Student,String> contactNumberColumn = new TableColumn<>("Contact No.");
        contactNumberColumn.setMinWidth(170);
        contactNumberColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("contactNum"));

    //education
        TableColumn<Student,String> educaTableColumn = new TableColumn<>("Education");
        educaTableColumn.setMinWidth(70);
        educaTableColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("education"));

    //Address
        TableColumn<Student,String> addressColumn = new TableColumn<>("Address");
        addressColumn.setMinWidth(200);
        addressColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("address")); 
    
    //city
        TableColumn<Student,String> cityColumn = new TableColumn<>("City");
        cityColumn.setMinWidth(80);
        cityColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("city")); 

    //State
        TableColumn<Student,String> stateColumn = new TableColumn<>("State");
        stateColumn.setMinWidth(80);
        stateColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("state"));


    //Paid
        TableColumn<Student,Double> paidColumn = new TableColumn<>("Paid fee");
        paidColumn.setMinWidth(80);
        paidColumn.setCellValueFactory(new PropertyValueFactory<Student,Double>("paid"));

    //Fee
        TableColumn<Student,Double> feeColumn = new TableColumn<>("Total Fee");
        feeColumn.setMinWidth(80);
        feeColumn.setCellValueFactory(new PropertyValueFactory<Student,Double>("fee")); 

        columns = new ArrayList<>();

        columns.add(roomColumn);
        columns.add(nameColumn);
        columns.add(emailColumn);
        columns.add(contactNumberColumn);
        columns.add(educaTableColumn);
        columns.add(addressColumn);
        columns.add(cityColumn);
        columns.add(stateColumn);
        columns.add(paidColumn);
        columns.add(feeColumn);

        tableView = new TableView<>();

        tableView.setItems(StudentList.getStudentDetailsList());
        tableView.getColumns().addAll(columns);
        tableView.setPadding(new Insets(15));
        tableView.setMinHeight(700);
        tableView.setMaxWidth(1000);

        BorderPane borderPane2 = new BorderPane();
        borderPane2.setCenter(tableView);
    
    //backButton
        // Button backButton = new Button("Back");
        // backButton.setPadding(new Insets(10));
        // backButton.setAlignment(Pos.CENTER);
        // BorderPane borderPane4 = new BorderPane();
        // borderPane4.setBottom(backButton);
        // BorderPane.setAlignment(backButton, Pos.CENTER);
        // backButton.setOnAction(e->{
        //     window.setScene(primaryScene);
        // });

        VBox container = new VBox(10);
        container.getChildren().addAll(borderPane2);                                  //borderPane4

        return container;

        // scene = new Scene(container,1300,900);
        // window.setScene(scene);
        //window.show();
    }
}