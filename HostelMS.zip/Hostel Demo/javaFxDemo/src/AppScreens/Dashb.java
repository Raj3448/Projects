package AppScreens;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Dashb {

    static Stage window;
    static Scene primaryScene;
    static VBox inneBox2 = new VBox();
    static Object currentDetailsView;
    static Button lastClickedButton;
    
    public static void display(Stage primaryStage,Scene scene) {

        window = primaryStage;
        primaryScene = scene;
       
        VBox vBox = new VBox();
        vBox.setBackground(new Background(new BackgroundFill(Color.valueOf("#6214ff"), CornerRadii.EMPTY, javafx.geometry.Insets.EMPTY)));

    
        vBox.setPrefWidth(primaryStage.getWidth() * 0.33);

      
        vBox.setPrefHeight(primaryStage.getHeight());

        Label label = new Label("Hostel Management ");
        label.setPadding(new Insets(40, 0, 90, 20));
        label.setAlignment(Pos.CENTER);
        label.setStyle("-fx-font-size: 35px; -fx-font-weight: bold; -fx-text-fill: white;"); 

        Label label2 = new Label("Admin Dashboard                     ");
        label2.setPadding(new Insets(30, 0, 20, 30));
        label2.setAlignment(Pos.TOP_CENTER);
        label2.setStyle("-fx-font-size: 60px;-fx-font-weight: bold; -fx-text-fill:#6214ff;");
        HBox innerBox = new HBox(label2);
        innerBox.setBackground(new Background(new BackgroundFill(Color.valueOf("#6214ff"), CornerRadii.EMPTY, javafx.geometry.Insets.EMPTY)));
        innerBox.setMaxHeight(200);
    

        // AddUserButton
        Button addStudentBtn = new Button("Add Student                         ");
        addStudentBtn.setPadding(new Insets(30, 60, 30, 60));
        addStudentBtn.setOnAction(e -> {
            handleButtonClick(addStudentBtn,AddUserScreen.display());
        });
        addStudentBtn.setMinWidth(vBox.getWidth());
        addStudentBtn.setMinHeight(vBox.getWidth() * 0.20);
        addStudentBtn.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;-fx-background-color: #6214ff; -fx-text-fill: white;");

        // EditUserButton
        Button editStudent = new Button("Edit Student                         ");
        editStudent.setPadding(new Insets(30, 60, 30, 60));
        editStudent.setOnAction(e -> {
           handleButtonClick(editStudent,EditStudentScreen.display());
        });
        editStudent.setMinWidth(vBox.getWidth());
        editStudent.setMinHeight(vBox.getWidth() * 0.20);
        editStudent.setStyle("-fx-background-color:#6214ff;  -fx-text-fill: white;-fx-font-size: 24px;  -fx-font-weight: bold;");

        // DueFeeButton
        Button dueFeeButton = new Button("Due Fee                                 ");
        dueFeeButton.setPadding(new Insets(30, 60, 30, 60));
        dueFeeButton.setOnAction(e -> {
            handleButtonClick(dueFeeButton,DueFeeScreen.display());
        });
        dueFeeButton.setMinWidth(vBox.getWidth());
        dueFeeButton.setMinHeight(vBox.getWidth() * 0.20);
        dueFeeButton.setStyle("-fx-background-color: #6214ff;  -fx-text-fill: white;-fx-font-size: 24px;-fx-font-weight: bold;");

        // ViewDetailsButton
        Button viewDetailsButton = new Button("View Details                         ");
        viewDetailsButton.setPadding(new Insets(30, 60, 30, 60));
        viewDetailsButton.setOnAction(e -> {
            handleButtonClick(viewDetailsButton,ViewStudentDetailsScreen.display());
        });
        viewDetailsButton.setMinWidth(vBox.getWidth());
        viewDetailsButton.setMinHeight(vBox.getWidth() * 0.20);
        viewDetailsButton.setStyle("-fx-background-color: #6214ff;  -fx-text-fill: white;-fx-font-size: 24px;  -fx-font-weight: bold;");

         // LogOut 
        Button LogOutButton = new Button("Log Out                         ");
        LogOutButton.setPadding(new Insets(30, 60, 30, 60));
        LogOutButton.setOnAction(e -> {
            handleButtonClick(LogOutButton,AddUserScreen.display());
            window.setTitle("LogIn Page");
            window.setScene(primaryScene);
        });
        LogOutButton.setMinWidth(vBox.getWidth());
        LogOutButton.setMinHeight(vBox.getWidth() * 0.20);
        LogOutButton.setStyle("-fx-background-color: #6214ff;  -fx-text-fill: white;-fx-font-size: 24px;  -fx-font-weight: bold;");

        vBox.getChildren().addAll(label, addStudentBtn, editStudent, dueFeeButton, viewDetailsButton,LogOutButton);
        // ...


     
        VBox rightVbox = new VBox(40);
        
        rightVbox.getChildren().addAll(label2,inneBox2);

        


                // Create an HBox to hold the VBox and the main content
                HBox root = new HBox(vBox,rightVbox);

                // Create the main scene
                scene = new Scene(root, 1400, 900);

                primaryStage.setScene(scene);
                primaryStage.show();
    }
    private static void handleButtonClick(Button clickedButton, Node detailsView) {
        // Remove the text color change from the last clicked button
       
        if (lastClickedButton != null) {
            lastClickedButton.setStyle("-fx-background-color: #6214ff; -fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: white;");
        }

        // Change the text color for the clicked button
        clickedButton.setStyle("-fx-background-color: #6214ff; -fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #14ff24;");
        lastClickedButton = clickedButton;

        // Remove the currentDetailsView (if it exists)
        if (currentDetailsView != null) {
            inneBox2.getChildren().remove(currentDetailsView);
        }

        // Add the newDetailsView to inneBox2
        inneBox2.getChildren().add(detailsView);

        // Update the currentDetailsView reference
        currentDetailsView = detailsView;
    }
    
}
