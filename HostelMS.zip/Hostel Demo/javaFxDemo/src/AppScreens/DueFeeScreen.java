package AppScreens;

import java.util.ArrayList;
import java.util.List;

import Models.Student;
import StateManagement.StudentList;
import javafx.geometry.Insets;

import javafx.scene.Scene;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;

import javafx.scene.layout.VBox;
import javafx.stage.Stage;



public class DueFeeScreen {

    TableView<Student> tableView;
    List<TableColumn<Student, ?>> columns;
    
    Stage window;
    Scene primaryScene;
    public static VBox display(){

        DueFeeScreen dueFeeScreen = new DueFeeScreen();
        // dueFeeScreen.window = stage;
        // dueFeeScreen.primaryScene = scene;

        // Label label = new Label("Peding Fees Student List");
        // label.setPadding(new Insets(10, 0, 0, 15));
        // label.setStyle("-fx-font-size: 40px;");
        // BorderPane borderPane = new BorderPane();
        // borderPane.setTop(label);

    //RoomNumber
        TableColumn<Student,Integer> roomColumn = new TableColumn<>("Room No.");
        roomColumn.setMinWidth(50);
        roomColumn.setCellValueFactory(new PropertyValueFactory<Student,Integer>("roomNumber"));

    //Student Name
        TableColumn<Student,String> nameColumn = new TableColumn<>("Names");
        nameColumn.setMinWidth(320);
        nameColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("studentName"));

    //contactNumber
        TableColumn<Student,String> contactNumberColumn = new TableColumn<>("Contact No.");
        contactNumberColumn.setMinWidth(170);
        contactNumberColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("contactNum"));
    
    //remaining fee
        TableColumn<Student,Double> remainingFee = new TableColumn<>("Pending Fees");
        remainingFee.setMinWidth(180);
        remainingFee.setCellValueFactory(new PropertyValueFactory<Student,Double>("remainingFee"));

    //Total fee
        TableColumn<Student,Double> feeColumn = new TableColumn<>("Total Fees");
        feeColumn.setMinWidth(180);
        feeColumn.setCellValueFactory(new PropertyValueFactory<Student,Double>("fee"));

    
    
        dueFeeScreen.columns = new ArrayList<>();

        dueFeeScreen.columns.add(roomColumn);
        dueFeeScreen.columns.add(nameColumn);
        dueFeeScreen.columns.add(contactNumberColumn);
        dueFeeScreen.columns.add(remainingFee);
        dueFeeScreen.columns.add(feeColumn);

        dueFeeScreen.tableView = new TableView<>();
        
        dueFeeScreen.tableView.setItems(StudentList.getRemainingFee());
        dueFeeScreen.tableView.getColumns().addAll(dueFeeScreen.columns);

        dueFeeScreen.tableView.setPadding(new Insets(15));
        dueFeeScreen.tableView.setMinHeight(900);
        dueFeeScreen.tableView.setMaxHeight(1200);

        BorderPane borderPane2 = new BorderPane();
        borderPane2.setCenter(dueFeeScreen.tableView);

        // Button backButn = new Button("Back");
        // backButn.setPadding(new Insets(10));
        // backButn.setAlignment(Pos.CENTER);
        // backButn.setOnAction(e->{
        //     dueFeeScreen.window.setScene(dueFeeScreen.primaryScene);
        // });

        // HBox hBox = new HBox(backButn);
        // hBox.setAlignment(Pos.CENTER);


        // BorderPane borderPane3 = new BorderPane();
        // borderPane3.setBottom(hBox);

        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(borderPane2);

        // scene = new Scene(vbox,1300,900);
        // dueFeeScreen.window.setScene(scene);
        // dueFeeScreen.window.show();

        return vbox;
    }
}
