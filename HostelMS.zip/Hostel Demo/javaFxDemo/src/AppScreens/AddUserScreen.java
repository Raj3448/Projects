package AppScreens;

import Models.Student;
import StateManagement.StudentList;
import Widgets.ErrorWidget;
import Widgets.SubmittedWidget;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class AddUserScreen {

    static Scene PrimaryScene;
    
    public static VBox display(){

        // PrimaryScene = scene;

        // window.setTitle("Hostel Mangement System");
       

        // Label label = new Label("Add New Student");
        // label.setPadding(new Insets(50, 0, 0, 30));
        // label.setStyle("-fx-font-size: 60px;");
        // BorderPane borderPane = new BorderPane();
        // borderPane.setTop(label);

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(30, 50, 20, 50));
        gridPane.setVgap(10);
        gridPane.setHgap(30);

//Student Name
        Label stuNamLabel = new Label("Student Name ");
        GridPane.setConstraints(stuNamLabel, 0, 1);
        stuNamLabel.setStyle("-fx-font-size: 25px;");

        TextField stuNamTextField = new TextField();
        GridPane.setConstraints(stuNamTextField, 1, 1);
        //stuNamTextField.setPrefWidth(400); 
        stuNamTextField.setMinWidth(300);
        stuNamTextField.setMaxHeight(30);

//email
        Label emailLabel = new Label("Email ");
        emailLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(emailLabel, 0, 2);

        TextField emailTextField = new TextField();
        GridPane.setConstraints(emailTextField, 1, 2);

//Education
        Label educationLabel = new Label("Education ");
        educationLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(educationLabel, 0, 3);

        ComboBox<String> educationComboBox = new ComboBox<>();
        educationComboBox.getItems().addAll("FE Engg","SE Engg","TE Engg","BE Engg","11 std","12 std","BSc","MSc","MTech","BTech","Agri.C","Other");
        educationComboBox.setPromptText("Select Education");
        GridPane.setConstraints(educationComboBox, 1, 3);

//Fee
        Label feeLabel = new Label("Fee ");
        feeLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(feeLabel, 0, 4);

        TextField feeTextField = new TextField();
        GridPane.setConstraints(feeTextField, 1, 4);     

        
//Paid
        Label paidLabel = new Label("Paid ");
        paidLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(paidLabel, 0, 5);

        TextField paidTextField = new TextField();
        GridPane.setConstraints(paidTextField, 1, 5);     

//roomNumber
        Label roomLabel = new Label("Room No. ");
        roomLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(roomLabel, 0, 6);

        TextField roomTextField = new TextField();
        GridPane.setConstraints(roomTextField, 1, 6);     

//address
        Label addressLabel = new Label("Address ");
        addressLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(addressLabel, 0, 7);

        TextField addressTextField = new TextField();
        GridPane.setConstraints(addressTextField, 1, 7);      

//City
        Label cityLabel = new Label("City ");
        cityLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(cityLabel, 0, 8);

        TextField cityTextField = new TextField();
        GridPane.setConstraints(cityTextField, 1, 8);  


//State
        Label stateLabel = new Label("State");
        stateLabel.setStyle("-fx-font-size: 30px;");
        GridPane.setConstraints(stateLabel, 0, 9);

        TextField stateTextField = new TextField();
        GridPane.setConstraints(stateTextField, 1, 9);  

//Contact Number
        Label contactLabel = new Label("Contact Number");
        contactLabel.setStyle("-fx-font-size: 25px;");
        GridPane.setConstraints(contactLabel, 0, 10);

        TextField contactTextField = new TextField();
        GridPane.setConstraints(contactTextField, 1, 10); 

        gridPane.getChildren().addAll(stuNamLabel,stuNamTextField,emailLabel,emailTextField,educationLabel,educationComboBox,feeLabel,feeTextField,paidLabel,paidTextField,roomLabel,roomTextField,addressLabel,addressTextField,cityLabel,cityTextField,stateLabel,stateTextField,contactLabel,contactTextField);
        BorderPane borderPane3 = new BorderPane();
        gridPane.setAlignment(Pos.CENTER_LEFT);
        borderPane3.setCenter(gridPane);
        BorderPane.setAlignment(gridPane, Pos.CENTER);
        
//Submit Button
        Button subButton = new Button("Submit");
        subButton.setPadding(new Insets(10));
        subButton.setAlignment(Pos.CENTER);
        BorderPane borderPane2 = new BorderPane();
        borderPane2.setBottom(subButton);
        BorderPane.setAlignment(subButton, Pos.CENTER);
       

//Back Button
        // Button backButton = new Button("Back");
        // backButton.setPadding(new Insets(10));
        // backButton.setAlignment(Pos.CENTER);
        // BorderPane borderPane4 = new BorderPane();
        // borderPane4.setBottom(backButton);
        // BorderPane.setAlignment(backButton, Pos.CENTER);
        // backButton.setOnAction(e->{
        //     window.setScene(PrimaryScene);
        // });

//Container

        VBox container = new VBox(10);
        
        container.getChildren().addAll(borderPane3,borderPane2);

        //scene = new Scene(container,1300 ,900);

        subButton.setOnAction(e->{

                
                String studentName ;
                String roomNumber;
                String education ;
                double fee = 0.0;
                double paid = 0.0;
                String address;
                String email ;
                String city ;
                String state;
                String contactNum;

                studentName = stuNamTextField.getText();
                roomNumber = roomTextField.getText();
                try{
                        fee = Double.parseDouble(feeTextField.getText());
                        paid = Double.parseDouble(paidTextField.getText());
                    
                        
                }catch(NumberFormatException nfe){

                        ErrorWidget.display("Error Occured","Enter fee in number");
                        paidTextField.clear();
                        feeTextField.clear();
                }
                education = educationComboBox.getValue();
               
                address = addressTextField.getText();
                email = emailTextField.getText();
                city = cityTextField.getText();
                state = stateTextField.getText();
                contactNum = contactTextField.getText();
                System.out.println(state);
                System.out.println(contactNum);
                
        

            if(studentName.length() == 0 || email.length() == 0 || address.length() == 0 || feeTextField.getLength() == 0 || paidTextField.getLength() == 0 || city.length() == 0 || state.length() == 0 || contactNum.length() == 0){

                ErrorWidget.display("Error Occured", "Field missing please enter.");
            }else if(!(emailTextField.getText().contains("@"))){

                ErrorWidget.display("Error Occured", "Invalid email Id");
            }else if(educationComboBox.getValue() == null){

                ErrorWidget.display("Error Occured", "Select Education");
            }else if(paid > fee){

                ErrorWidget.display("Error Occured","Paid fee never greater than total fee");
                paidTextField.clear();
            }else{
                System.out.println("{"+studentName+", "+contactNum+","+state+","+paid+","+"}");
                StudentList.setStudents(new Student(studentName, roomNumber, education, fee ,paid ,address, email, city, state, contactNum));
                SubmittedWidget.display("Submitted"," Successfully Added New Student");

                //Tammy

                stuNamTextField.clear();
                roomTextField.clear();
                feeTextField.clear();
                cityTextField.clear();
                paidTextField.clear();
                emailTextField.clear();
                addressTextField.clear();
                stateTextField.clear();
                educationComboBox.getItems().clear();
                contactTextField.clear();
           }
        });

        return container;

        // window.setScene(scene);
        // window.show();
    }
}
