package AppScreens;

import java.util.ArrayList;
import java.util.List;

import Models.Student;
import StateManagement.StudentList;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class EditStudentScreen {
  
    static Stage window;
    static Scene primaryScene;

    static ObservableList<Student> allStudents;

    static TableView<Student> tableView;
    static List<TableColumn<Student, ?>> columns;

    static TextField roomTextField;
    static TextField paidTextField;
    static TextField contactNumTextField;
    static ComboBox<String> educationComboBox;
    static Student studentEntrySelected;
    

    public static VBox display(){

        // primaryScene = scene;
        // window = primaryStage;

        // window.setTitle("Hostel Management System");

        // Label label = new Label("Edit Student Details");
        // label.setPadding(new Insets(10, 0, 0, 15));
        // label.setStyle("-fx-font-size: 60px;");
        // BorderPane borderPane = new BorderPane();
        // borderPane.setTop(label);

    //RoomNumber
        TableColumn<Student,Integer> roomColumn = new TableColumn<>("Room No.");
        roomColumn.setMinWidth(30);
        roomColumn.setCellValueFactory(new PropertyValueFactory<Student,Integer>("roomNumber"));

    //Student Name
        TableColumn<Student,String> nameColumn = new TableColumn<>("Names");
        nameColumn.setMinWidth(200);
        nameColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("studentName"));
    
    //Email
        TableColumn<Student,String> emailColumn = new TableColumn<>("Emails");
        emailColumn.setMinWidth(250);
        emailColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("email"));
    
    //contactNumber
        TableColumn<Student,String> contactNumberColumn = new TableColumn<>("Contact No.");
        contactNumberColumn.setMinWidth(200);
        contactNumberColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("contactNum"));

    //education
        TableColumn<Student,String> educaTableColumn = new TableColumn<>("Education");
        educaTableColumn.setMinWidth(80);
        educaTableColumn.setCellValueFactory(new PropertyValueFactory<Student,String>("education"));


    //Paid
        TableColumn<Student,Double> paidColumn = new TableColumn<>("Paid fees");
        paidColumn.setMinWidth(130);
        paidColumn.setCellValueFactory(new PropertyValueFactory<Student,Double>("paid"));

    //Fee
        TableColumn<Student,Double> feeColumn = new TableColumn<>("Total Fees");
        feeColumn.setMinWidth(130);
        feeColumn.setCellValueFactory(new PropertyValueFactory<Student,Double>("fee")); 

        columns = new ArrayList<>();

        columns.add(roomColumn);
        columns.add(nameColumn);
        columns.add(emailColumn);
        columns.add(contactNumberColumn);
        columns.add(educaTableColumn);
        columns.add(paidColumn);
        columns.add(feeColumn);

        tableView = new TableView<>();

        tableView.setItems(StudentList.getStudentDetailsList());
        tableView.getColumns().addAll(columns);
        tableView.setPadding(new Insets(15));
        tableView.setMinHeight(500);
        tableView.setMaxWidth(1200);


        BorderPane borderPane2 = new BorderPane();
        borderPane2.setCenter(tableView);

        roomTextField = new TextField();
        roomTextField.setPromptText("Room No.");
        roomTextField.setMinWidth(150);
        roomTextField.setMaxHeight(30);

        paidTextField = new TextField();
        paidTextField.setPromptText("Paid");
        paidTextField.setMinWidth(150);
        paidTextField.setMaxHeight(30);

        contactNumTextField = new TextField();
        contactNumTextField.setPromptText("Contact Number");
        contactNumTextField.setMinWidth(150);
        contactNumTextField.setMaxHeight(30);

        educationComboBox = new ComboBox<>();
        educationComboBox.getItems().addAll("FE Engg","SE Engg","TE Engg","BE Engg","11 std","12 std","BSc","MSc","MTech","BTech","Agri.C","Other");
        educationComboBox.setPromptText("Select Education");
        educationComboBox.setMinWidth(150);

        
        

       
        Button updateButn = new Button("Update");
        updateButn.setPadding(new Insets(10));
        updateButn.setAlignment(Pos.CENTER);
        updateButn.setOnAction(e->{
            
              updateSelectedEntry();
            
        });

        Button deleteButn = new Button("Delete");
        deleteButn.setPadding(new Insets(10));
        deleteButn.setAlignment(Pos.CENTER);
        deleteButn.setOnAction(e->{
            deleteStudentEntry();
        });


        // Button backButn = new Button("Back");
        // backButn.setPadding(new Insets(10));
        // backButn.setAlignment(Pos.CENTER);
        // backButn.setOnAction(e->{
        //     window.setScene(primaryScene);
        // });

        HBox hBox1 = new HBox(10);
        hBox1.getChildren().addAll(updateButn,deleteButn);
        hBox1.setAlignment(Pos.CENTER);

        BorderPane borderPane3 = new BorderPane();
        borderPane3.setBottom(hBox1);

        HBox hBox = new HBox(10);
        hBox.getChildren().addAll(roomTextField,paidTextField,contactNumTextField,educationComboBox);
        hBox.setPadding(new Insets(10));
        
        VBox vbox = new VBox(25);
        vbox.getChildren().addAll(borderPane2,hBox,borderPane3);

        return vbox;

        // scene = new Scene(vbox,1300,900);

        // window.setScene(scene);
        // window.show();
    } 
    
    private static void deleteStudentEntry(){

        allStudents = tableView.getItems();
        Student studentEntrySelected = tableView.getSelectionModel().getSelectedItem();

        allStudents.removeIf(extractedEntry -> extractedEntry.equals(studentEntrySelected));

    }

    private static void updateSelectedEntry() {

        Student selectedStudent = tableView.getSelectionModel().getSelectedItem();

        allStudents = tableView.getItems();
    
        if (selectedStudent != null && roomTextField.getText() != null  && paidTextField.getText() != null && contactNumTextField.getText() != null && educationComboBox.getValue() != null) {
            String roomNumber = roomTextField.getText();
            String contactNumber = contactNumTextField.getText();
            int paidFee = Integer.parseInt(paidTextField.getText());
            String education = educationComboBox.getValue();
    
            selectedStudent.setRoomNumber(roomNumber);
            selectedStudent.setContactNumber(contactNumber);
            selectedStudent.setPaidfee(paidFee + selectedStudent.getPaidFee());
            selectedStudent.setEducation(education);

            //Tammy
            
    
            tableView.refresh();
    
            roomTextField.clear();
            contactNumTextField.clear();
            paidTextField.clear();
            educationComboBox.getItems().clear();
        }
    }
    
}
