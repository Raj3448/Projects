package StateManagement;

import java.util.List;
import java.util.stream.Collectors;

import Models.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class StudentList {
    
    private static ObservableList<Student> studentList = FXCollections.observableArrayList();

//Set and getStudents data manually
    public static ObservableList<Student> getStudents(){

        ObservableList<Student>  students = FXCollections.observableArrayList();
        students.add(new Student("Rajkumar Chavan", "412", "BEngg", 14000 ,7000,"421 juni laxmi chawal doangaon road solapur ", "rajchavan6659@gmail.com", "Solapur", "Maharashtra","9156313158"));
        students.add(new Student("Tanmay Pawar", "456", "BEngg", 27000 ,12000,"Shinavar peth, pune ", "tanmaypawar@gmail.com", "Pune", "Maharashtra","7057530774"));
        students.add(new Student("Kailas Dukare", "467", "BEngg", 20000 ,15000,"Mangalwar peth, pune", "kailas0987@gmail.com", "Parbhani", "Maharashtra","7028292205"));
    
        studentList = students; 
        System.out.println((ObservableList<Student>)studentList);  
        
        return (ObservableList<Student>) studentList;
    }

//SetStudents data by admin
    public static void setStudents(Student studentDetails){
        
        studentList.add(studentDetails);
    }

//getStudents List
    public static ObservableList<Student> getStudentDetailsList(){
            return ((ObservableList<Student>) studentList);
    }

    public static ObservableList<Student> getRemainingFee() {

        List<Student> pendingFeesList =  studentList.stream().filter(student ->{
            return  student.getRemainingFee() > 0;
        }).collect(Collectors.toList());
        
        ObservableList<Student> remList = FXCollections.observableArrayList(pendingFeesList);

        System.out.println(remList);

        return remList;
    }
}
