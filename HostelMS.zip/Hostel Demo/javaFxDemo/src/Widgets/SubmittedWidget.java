package Widgets;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SubmittedWidget {
    public static void display(String title,String message){

        Stage window = new Stage();
        window.setTitle(title);

        Label lable = new Label("✅"+message);
        lable.setStyle("-fx-font-size: 20px;");
        
        Button okBtn = new Button("Ok");
        okBtn.setOnAction(e->{
            window.close();
        });

        VBox layOutBox = new VBox(40);
        layOutBox.setAlignment(Pos.CENTER);
        layOutBox.getChildren().addAll(lable,okBtn);

        Scene scene = new Scene(layOutBox,500,150);

        window.setScene(scene);
        window.showAndWait(); 
    }
}
