package Models;

public class Student {
    
    String studentName;
    String roomNumber;
    String education;
    double fee;
    double paid;
    String address;
    String email;
    String city;
    String state;
    String contactNum;
    double remainingFee;


    public Student(){

    }

    public Student(String studentName,String roomNumber,String education,double fee,double paid,String address,String email,String city,String state,String contactNum){

        this.studentName = studentName;
        this.roomNumber = roomNumber;
        this.education = education;
        this.fee = fee;
        this.paid = paid;
        this.address = address;
        this.email = email;
        this.city = city;
        this.state = state;
        this.contactNum = contactNum;

    }
//studentName
    public void setStudentName(String studentName){   
        this.studentName = studentName;
    }

    public String getStudentName(){
        return this.studentName;
    }
//roomNumber
    public void setRoomNumber(String roomNumber2){   
        this.roomNumber = roomNumber2;
    }

    public String getRoomNumber(){
        return this.roomNumber;
    }
//education
    public void setEducation(String education){   
        this.education = education;
    }

    public String getEducation(){
        return this.education;
    }
//Fee
    public void setFee(double fee){   
       this.fee = fee;
    }

    public double getFee(){
        return this.fee;
    }

//Paid
    public void setPaidfee(double paid){   
       this.paid = paid;
    }

    public double getPaidFee(){
        return this.paid;
    }

//address
    public void setAddress(String address){   
       this.address = address;
    }

    public String getAddress(){
        return this.address;
    }
//Email
    public void setEmail(String email){   
       this.email = email;
    }

    public String getEmail(){
        return this.email;
    }

//City
    public void setCity(String city){   
      this.city = city;
    }

    public String getCity(){
        return this.city;
    }
//state
    public void setStateName(String state){   
      this.state = state;
    }

    public String getStateName(){
        return this.state;
    }

//Contact Number
    public void setContactNumber(String contactNum){   
      this.contactNum = contactNum;
    }

    public String getContactNumber(){
        return this.contactNum;
    }

//remaining Fee

    public double getRemainingFee(){
        return this.fee - this.paid;
    }
}